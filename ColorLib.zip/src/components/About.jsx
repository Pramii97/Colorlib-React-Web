import React from 'react';


function About(){
    return (
        <div className="about">
            <h1>About </h1>

            <div className="navbar-list">
 
                        </div>
        </div>
    )
}

export default About;